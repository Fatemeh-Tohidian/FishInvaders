package views.pilot;
import java.awt.Graphics2D;
import java.io.IOException;

import views.pilot.submarine.SubmarineView;

public class PilotView {
	
	public static void paintPilot(Graphics2D g2d) {
		
		try {
			SubmarineView.paintSubmarine(g2d);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
