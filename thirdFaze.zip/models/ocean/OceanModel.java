package models.ocean;
import java.util.ArrayList;

import controller.levels.fishGroups.FishGroupController;
import models.levels.Level;
import models.pilot.Pilot;

public class OceanModel {
	
	private ArrayList<Pilot> currentPilots;
	private Pilot currentPilot;
	private Level currentLevel;
	private FishGroupController currentWave;
	
	public ArrayList<Pilot> getCurrentPilots() {
		return currentPilots;
	}
	public void setCurrentPilots(ArrayList<Pilot> currentPilots) {
		this.currentPilots = currentPilots;
	}
	public Pilot getCurrentPilot() {
		return currentPilot;
	}
	public void setCurrentPilot(Pilot currentPilot) {
		this.currentPilot = currentPilot;
	}
	public Level getCurrentLevel() {
		return currentLevel;
	}
	public void setCurrentLevel(Level currentLevel) {
		this.currentLevel = currentLevel;
	}
	public FishGroupController getCurrentWave() {
		return currentWave;
	}
	public void setCurrentWave(FishGroupController currentWave) {
		this.currentWave = currentWave;
	}
	public void update(OceanModel oceanModel) {
		this.currentLevel = oceanModel.currentLevel;
		this.currentPilots = oceanModel.currentPilots;
		this.currentPilot = oceanModel.currentPilot;
		
	}
	
}
