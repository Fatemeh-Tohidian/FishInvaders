package models.pilot;

import models.pilot.submarine.Submarine;

public class Pilot {
private Submarine submarine;
private long score;
private long heart;
private long countOfFriedFish;

public Pilot(Submarine submarine, long score, long countOfFriedFish ,long heart) {
	super();
	this.submarine = submarine;
	this.score = score;
	this.countOfFriedFish = countOfFriedFish;
}

public Submarine getSubmarine() {
	return submarine;
}
public void setSubmarine(Submarine submarine) {
	this.submarine = submarine;
}
public long getScore() {
	return score;
}
public void setScore(long score) {
	this.score = score;
}
public long getCountOfFriedFish() {
	return countOfFriedFish;
}
public void setCountOfFriedFish(long countOfFriedFish) {
	this.countOfFriedFish = countOfFriedFish;
}
public long getHeart() {
	return heart;
}
public void setHeart(long heart) {
	this.heart = heart;
}

}
