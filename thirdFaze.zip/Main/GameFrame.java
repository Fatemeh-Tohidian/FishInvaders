package Main;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import javax.swing.JFrame;
import controller.ocean.ServerOceanController;
import controller.ocean.listeners.ClientListenerController;
import models.MainModel;
import models.levels.Level;
import models.ocean.OceanModel;
import models.pilot.Pilot;
import models.pilot.submarine.Submarine;
import models.pilot.submarine.firingSystem.FiringSystemModel;
import views.ocean.OceanView;

public class GameFrame {
	private static double width ;
	private static double height;
	public GameFrame() {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		width = screenSize.getWidth();
		height = screenSize.getHeight();
		JFrame frame = new JFrame();
		frame.setLayout(null);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		frame.setUndecorated(true);
		OceanModel oceanModel = new OceanModel();
		OceanView oceanView = new OceanView();
		oceanView.setSize(new Dimension((int)width, (int)height));
		ClientListenerController  listenersController = new ClientListenerController();
		oceanView.addMouseMotionListener(listenersController);
		oceanView.addMouseListener(listenersController);
		MainModel.getModel().setOceanModel(oceanModel);
		MainModel.getModel().setOceanView(oceanView);
		ArrayList<Pilot> pilots = new ArrayList<Pilot>();
		FiringSystemModel firingSystemModel = new FiringSystemModel(0, 1, 3);
		oceanView.setCursor(oceanView.getToolkit().createCustomCursor( new BufferedImage( 1, 1, BufferedImage.TYPE_INT_ARGB ),new Point(),null ) );
		Submarine submarine = new Submarine(700,700,firingSystemModel,"RED");
		Pilot p = new Pilot(submarine, 0, 0, 3);
		pilots.add(p);
		MainModel.getModel().getOceanModel().setCurrentPilots(pilots);
		MainModel.getModel().getOceanModel().setCurrentPilot(p);
		MainModel.getModel().getOceanModel().setCurrentLevel(Level.Level1);
		MainModel.getModel().getOceanModel().setCurrentWave(Level.Level1.getFishGroups().get(0));;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(oceanView);
		frame.setVisible(true);
		ServerOceanController serverOceanController =new ServerOceanController(oceanModel, oceanView);
		serverOceanController.run();
	}
	public static double getWidth() {
		return width;
	}
	public static void setWidth(double width) {
		GameFrame.width = width;
	}
	public static double getHeight() {
		return height;
	}
	public static void setHeight(double height) {
		GameFrame.height = height;
	}
}
