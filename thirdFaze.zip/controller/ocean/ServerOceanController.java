package controller.ocean;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import controller.levels.LevelController;
import controller.pilot.PilotController;
import models.ocean.OceanModel;
import views.ocean.OceanView;

public class ServerOceanController implements Runnable {
	private OceanModel oceanModel;
	private OceanView oceanView;

	public ServerOceanController(OceanModel oceanModel, OceanView oceanView) {
		this.oceanModel = oceanModel;
		this.oceanView = oceanView;
	}
	@Override
	public void run() {
		LevelController  levelController = new LevelController();
		Timer timer = new Timer(20, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				PilotController.updatePilots();
				levelController.updateCuurentLevel();
				oceanView.revalidate();
				oceanView.repaint();
				}
		});
		timer.start();
	}
	public OceanModel getOceanModel() {
		return oceanModel;
	}
	public void setOceanModel(OceanModel oceanModel) {
		this.oceanModel = oceanModel;
	}
}
