package controller.ocean;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import javax.swing.Timer;
import com.google.gson.Gson;
import models.ocean.OceanModel;
import views.ocean.OceanView;


public class ClientOceanController implements  Runnable {
	private OceanView oceanView;
	private OceanModel oceanModel;
	Socket socket;
	Gson gson = new Gson();
	PrintWriter writer;
	Scanner scanner;
	public  ClientOceanController(OceanView oceanView,OceanModel oceanModel) throws UnknownHostException, IOException{
		this.oceanView = oceanView;
		this.oceanModel = oceanModel;
		socket = new Socket("127.0.0.1", 2117);
		writer = new PrintWriter(socket.getOutputStream(),true);
		scanner = new Scanner (socket.getInputStream());

	}
	@Override
	public void run() {
		Timer timer = new Timer(20, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//hala felan
	//			sendCommand();
				updateView();
			}


		});
		timer.start();
	}
	public OceanView getOceanView() {
		return oceanView;
	}
	public void setOceanView(OceanView oceanView) {
		this.oceanView = oceanView;
	}
	public OceanModel getOceanModel() {
		return oceanModel;
	}
	public void setOceanModel(OceanModel oceanModel) {
		this.oceanModel = oceanModel;
	}
//	private void sendCommand() {
//		if(oceanView.getClientListenerController().isMove()){
//			writer.println("move");
//			writer.println(oceanView.getClientListenerController().getSubmarineX());
//			writer.println(oceanView.getClientListenerController().getSubmarineY());
//			writer.flush();
//		}
//		if(oceanView.getClientListenerController().isShootBullet()){
//			writer.println("shootBullet");
//			writer.println(oceanView.getClientListenerController().getBulletFirsLocationX());
//			writer.println(oceanView.getClientListenerController().getBulletFirsLocationY());
//			writer.flush();
//		}
//		if(oceanView.getClientListenerController().isShootBomb()){
//			writer.println("shootBomb");
//			writer.println(oceanView.getClientListenerController().getBombFirsLocationX());
//			writer.println(oceanView.getClientListenerController().getBombFirsLocationY());
//			writer.flush();
//		}
//
//	}
	private void updateView() {
		// TODO Auto-generated method stub
	// hala fellan	oceanModel = new OceanModel();
		oceanView.repaint();
	}
}
