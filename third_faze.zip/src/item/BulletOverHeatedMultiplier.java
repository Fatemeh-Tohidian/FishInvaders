package item;

public class BulletOverHeatedMultiplier extends EmpowerItem{

	@Override
	public void influence() {
		// TODO Auto-generated method stub
		
	}

}
