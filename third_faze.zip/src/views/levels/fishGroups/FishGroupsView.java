package views.levels.fishGroups;

import java.awt.Graphics2D;
import java.awt.Point;
import java.io.IOException;
import java.util.ArrayList;
import Assets.ImageAsset;
import item.EmpowerItem;
import models.MainModel;
import models.levels.items.Fish;

public class FishGroupsView {
	static int fishIndex;

	public static void  paintFishGroup(Graphics2D g2d) throws IOException{

		paintFishes(g2d);
		paintUrchins(g2d);
		paintFriedFishes(g2d);
		paintFriedFishes(g2d);
		paintImpoweringItems(g2d);
	}
	private static void paintFishes(Graphics2D g2d) throws IOException{
		ArrayList<Fish> fishes = MainModel.getModel().getOceanModel().getCurrentWave().getFishes();
		for(int  i = 0 ;i < fishes.size(); i++){
			if(fishes.get(i).isValid()){
				animateFish();
				g2d.drawImage(ImageAsset.createImageAsset().getFishes().get(MainModel.getModel().getOceanModel().getCurrentWave().getFishType().getImageCode()+"Fish").get(fishIndex), (int)fishes.get(i).getX(), (int)fishes.get(i).getY(), null);
			}}
	}
	private static void paintUrchins(Graphics2D g2d) throws IOException {
		ArrayList<Point> urchins = MainModel.getModel().getOceanModel().getCurrentWave().getUrchins();
		for(int  i = 0 ;i < urchins.size(); i++){
			g2d.drawImage(((ImageAsset) ImageAsset.createImageAsset()).getUrchins().get("urchin").get(0),(int)urchins.get(i).x,(int)urchins.get(i).y, 68, 68 , null);
		}
	}
	private static void paintFriedFishes(Graphics2D g2d) throws IOException{
		ArrayList<Point> friedFishes = MainModel.getModel().getOceanModel().getCurrentWave().getFriedFishes();
		for(int  i = 0 ;i < friedFishes.size(); i++){
			g2d.drawImage(ImageAsset.createImageAsset().getItems().get("friedFish"), friedFishes.get(i).x, friedFishes.get(i).y, null);
		}
	}
	private static void paintImpoweringItems(Graphics2D g2d) throws IOException{

		ArrayList<EmpowerItem> empowerItems = MainModel.getModel().getOceanModel().getCurrentWave().getEmpowerItems();
		for(int  i = 0 ;i < empowerItems.size(); i++){
			g2d.drawImage(ImageAsset.createImageAsset().getItems().get("greenGem"), (int)empowerItems.get(i).getX(), (int)empowerItems.get(i).getY(), null);
		}
	}
	private static void animateFish() {
		if(fishIndex < MainModel.getModel().getOceanModel().getCurrentWave().getFishType().getCountOfImages()-1){fishIndex++;}
		else{fishIndex =0 ;		
		}}
}
