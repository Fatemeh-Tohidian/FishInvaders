package views.ocean;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.IOException;
import javax.swing.JPanel;
import Assets.ImageAsset;
import Main.GameFrame;
import controller.ocean.listeners.ClientListenerController;
import models.MainModel;
import views.levels.fishGroups.FishGroupsView;
import views.levels.lastWaves.LastWaveView;
import views.ocean.bar.BarView;
import views.pilot.PilotView;


public class OceanView extends JPanel {
	private ClientListenerController clientListenerController;
	public OceanView() {
		clientListenerController = new ClientListenerController();
		this.addMouseListener(clientListenerController);
		this.addMouseMotionListener(clientListenerController);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Override
	public void paintComponent(Graphics graphics) {

		Graphics2D graphics2d = (Graphics2D) graphics.create();

		try {
			paintOcean(graphics2d);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public void paintOcean(Graphics2D graphics2D ) throws IOException{
		paintGameEnvironment(graphics2D);
		paintPilots(graphics2D);
		paintEnemies(graphics2D);
		graphics2D.dispose();
	}
	private void paintEnemies(Graphics2D graphics2D) throws IOException {
		if(MainModel.getModel().getOceanModel().getCurrentLevel().isInLastWave()){

			LastWaveView.paintLastWave(graphics2D);
		}
		else{
			FishGroupsView.paintFishGroup(graphics2D);
		}

	}
	private void paintGameEnvironment(Graphics2D graphics2D) throws IOException {
		paintBackground(graphics2D);
		paintBars(graphics2D);

	}
	private void paintPilots(Graphics2D graphics2D) {
		PilotView.paintPilot(graphics2D);

	}
	private void paintBars(Graphics2D graphics2D) throws IOException {
		BarView.paintBars(graphics2D);
	}


	private void paintBackground(Graphics2D graphics2D) {
		try {
			graphics2D.drawImage(ImageAsset.createImageAsset().getBackgrounds().get("gameBackground"), 0, 0, (int)GameFrame.getWidth() , (int)GameFrame.getHeight(), null);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	public ClientListenerController getClientListenerController() {
		return clientListenerController;
	}
	public void setClientListenerController(ClientListenerController clientListenerController) {
		this.clientListenerController = clientListenerController;
	}
}
