package controller.pilot;

import java.util.ArrayList;
import controller.pilot.submarine.SubmarineController;
import models.MainModel;
import models.pilot.Pilot;

public class PilotController {

	public static void updatePilots() {
		ArrayList<Pilot> pilots = MainModel.getModel().getOceanModel().getCurrentPilots();
		for(int i = 0 ;i < pilots.size() ; i++){
			SubmarineController.updateSubmarine(i);
		}

	}


}
